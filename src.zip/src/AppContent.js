import React, { useState } from 'react';
import InputForm from './components/InputForm';
import { calculateTotals } from './utils/calculations';
import bomData from './data/bom.json';

export default function AppContent() {
  const [result, setResult] = useState(null);

  const handleSubmit = (formData) => {
    const products = bomData.map(item => ({
      name: item["Product Name"],
      cost: item["Trade Price"],
      sell: item["Retail Price"],
      quantity: item["Quantity"]
    }));

    const calc = calculateTotals(
      products,
      formData.laborHours,
      formData.laborCost,
      formData.overheads
    );
    setResult({ ...calc, targetMargin: formData.targetMargin });
  };

  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold mb-4">Specifi Profit Optimiser</h1>
      <InputForm onSubmit={handleSubmit} />

      {result && (
        <div className="mt-6 p-4 border rounded-md space-y-2">
          <p>Total Revenue: £{result.totalRevenue.toFixed(2)}</p>
          <p>Total Cost: £{result.totalCosts.toFixed(2)}</p>
          <p>Gross Profit: £{result.profit.toFixed(2)}</p>
          <p>Margin: {(result.margin * 100).toFixed(2)}% (Target: {(result.targetMargin * 100).toFixed(2)}%)</p>
          <p>Status: {result.margin >= result.targetMargin ? "✅ Good" : "❌ Below Target"}</p>
          {result.flagged.length > 0 && (
            <div>
              <p>⚠️ Low margin items:</p>
              <ul>
                {result.flagged.map((item, i) => (
                  <li key={i}>{item.name} — Margin: {(item.margin * 100).toFixed(2)}%</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </main>
  );
}
