import { render, screen } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import App from './App';
import Home from './IndexPage'; // <-- Add this import

// Removed jest.mock to avoid double Router error

test('renders ProfitChecker form on /ProfitChecker', () => {
  render(
  <MemoryRouter initialEntries={["/ProfitChecker"]}>
      <Routes>
        <Route path="/" element={<ProfitChecker/>} /> {/* 👈 Renders at /app/ */}
      </Routes>
    </MemoryRouter>

  );
  const checkerHeading = screen.getByText(/Profit Check/i);
  expect(checkerHeading).toBeInTheDocument();
});


