import React, { useState } from 'react';
import Input from './Input';
import Button from './Button';

/**
 * @param {{ onSubmit: (data: Object) => void }} props
 */
export default function InputForm({ onSubmit }) {
  const [laborHours, setLaborHours] = useState("");
  const [laborCost, setLaborCost] = useState("");
  const [overheads, setOverheads] = useState("");
  const [targetMargin, setTargetMargin] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      laborHours: Number(laborHours),
      laborCost: Number(laborCost),
      overheads: Number(overheads),
      targetMargin: Number(targetMargin) / 100,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 border rounded-md bg-white shadow">
      <div>
        <label className="block mb-1 font-semibold">Labor Hours:</label>
        <Input
          type="number"
          value={laborHours}
          onChange={(e) => setLaborHours(e.target.value)}
          placeholder="Enter total labor hours"
        />
      </div>

      <div>
        <label className="block mb-1 font-semibold">Labor Cost per Hour:</label>
        <Input
          type="number"
          value={laborCost}
          onChange={(e) => setLaborCost(e.target.value)}
          placeholder="Enter cost per hour"
        />
      </div>

      <div>
        <label className="block mb-1 font-semibold">Fixed Overheads:</label>
        <Input
          type="number"
          value={overheads}
          onChange={(e) => setOverheads(e.target.value)}
          placeholder="Enter overheads"
        />
      </div>

      <div>
        <label className="block mb-1 font-semibold">Target Profit Margin (%):</label>
        <Input
          type="number"
          value={targetMargin}
          onChange={(e) => setTargetMargin(e.target.value)}
          placeholder="e.g. 25"
        />
      </div>

      <Button type="submit">Calculate Profitability</Button>
    </form>
  );
}
