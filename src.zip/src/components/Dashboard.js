import React from 'react';
import { Link, Routes, Route } from 'react-router-dom';
import { useAuth } from "../contexts/AuthContext";
import InputForm from './InputForm';
import ProfitChecker from './ProfitChecker';
import HealthIndicator from './HealthIndicator';
import ProductList from './ProductList';

export default function Dashboard() {
  const { logout } = useAuth();

const handleLogout = () => {
    logout();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-indigo-600 text-black p-4">
        <h1 className="text-xl font-bold">Dashboard</h1>
        <nav className="mt-2 space-x-4">
          <Link to="">Home</Link>
          <Link to="inputform">Input Form</Link>
          <Link to="profitchecker">Profit Checker</Link>
          <Link to="healthindicator">Health Indicator</Link>
          <Link to="productlist">Product List</Link>
       
      </nav>
<button
          onClick={handleLogout}
          className="bg-white text-indigo-700 px-4 py-2 rounded hover:bg-indigo-100 transition"
        >
          Logout
        </button>

      </header>

      <main className="flex-grow p-6 bg-gray-100">
        <Routes>
          <Route index element={<div>Welcome to your Dashboard. Select a tool above.</div>} />
          <Route path="inputform" element={<InputForm />} />
          <Route path="profitchecker" element={<ProfitChecker />} />
          <Route path="healthindicator" element={<HealthIndicator />} />
           <Route path="productlist" element={<ProductList />} />
        </Routes>
      </main>
    </div>
  );
}
