import React from "react";

/**
 * @param {{
 *   margin: number,
 *   targetMargin: number
 * }} props
 */
export default function HealthIndicator({ margin = 0, targetMargin = 0 }) {
  let status = "❌ Unhealthy";
  let message = "Profit margin is below target. Consider action to improve it.";

  if (margin >= targetMargin) {
    status = "✅ Healthy";
    message = "Great job! Margin meets or exceeds the target.";
  } else if (margin >= targetMargin * 0.7) {
    status = "⚠️ Warning";
    message = "Margin is close to target but could be better.";
  }

  return (
    <div className="p-6 bg-white rounded shadow-md">
      <h2 className="text-2xl font-bold mb-4 text-indigo-700">Health Indicator</h2>
      <p className="text-lg mb-2">
        <strong>Status:</strong> {status}
      </p>
      <p>{message}</p>
      <div className="mt-4">
        <p><strong>Current Margin:</strong> {(margin * 100).toFixed(2)}%</p>
        <p><strong>Target Margin:</strong> {(targetMargin * 100).toFixed(2)}%</p>
      </div>
    </div>
  );
}
