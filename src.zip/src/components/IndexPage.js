import React from "react";
import { useNavigate, Link } from "react-router-dom";
// import { Link } from 'react-router-dom';

export default function IndexPage() {
  const navigate = useNavigate();

  const handleLoginClick = () => {
    navigate("/login");
  };

  const handleSignupClick = () => {
    navigate("/signup");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-center">
      <h1 className="text-4xl font-bold mb-4">Welcome to Specifi Profit Optimiser</h1>
      <p className="mb-6 max-w-xl">Check your profitability, optimize margins and manage your business health, all in one place.</p>
      <div className="space-x-4">
        <Link
          to="/login"
          className="bg-black text-indigo-700 px-6 py-3 rounded font-semibold hover:bg-indigo-100 transition"
        >
          Login
        </Link>
        <Link
          to="/signup"
          className="bg-black text-indigo-700 px-6 py-3 rounded font-semibold hover:bg-indigo-100 transition"
        >
          Sign Up
        </Link>
        {/* <Link
          to="/dashboard"
          className="bg-black text-indigo-700 px-6 py-3 rounded font-semibold hover:bg-indigo-100 transition"
        >
          Go to Dashboard
        </Link> */}
      </div>
    </div>
  );
}
// function Home() {
//   return (
//     <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
//       <h1 className="text-4xl font-bold mb-4">Welcome to Specifi Profit Optimiser</h1>
//       <div className="space-x-4">
//         <Link
//           to="/login"
//           className="bg-white text-indigo-700 px-6 py-3 rounded font-semibold hover:bg-indigo-100 transition"
//         >
//           Login
//         </Link>
//         <Link
//           to="/signup"
//           className="bg-white text-indigo-700 px-6 py-3 rounded font-semibold hover:bg-indigo-100 transition"
//         >
//           Sign Up
//         </Link>
//       </div>
//     </div>
//   );
// }

// return <Home />;


