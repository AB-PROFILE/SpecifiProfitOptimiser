import React from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

/**
 * @param {{ result: Object }} props
 */
export default function ResultsDisplay({ result }) {
  if (!result) return null; // ✅ Don't render until data is ready!

  const {
    totalRevenue = 0,
    totalCosts = 0,
    profit = 0,
    margin = 0,
    targetMargin = 0,
    flagged = [],
    aiSuggestions = ""
  } = result;

  const exportPDF = async () => {
    const input = document.getElementById("profit-results");
    const canvas = await html2canvas(input);
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save("Profitability_Report.pdf");
  };

  return (
    <div id="profit-results" className="mt-6 p-6 bg-white rounded shadow-md">
      <h2 className="text-2xl font-bold mb-4 text-indigo-700">Profitability Results</h2>
      
      <div className="space-y-2">
        <p><strong>Total Revenue:</strong> £{totalRevenue.toFixed(2)}</p>
        <p><strong>Total Cost:</strong> £{totalCosts.toFixed(2)}</p>
        <p><strong>Gross Profit:</strong> £{profit.toFixed(2)}</p>
        <p>
          <strong>Margin:</strong> {(margin * 100).toFixed(2)}% (Target: {(targetMargin * 100).toFixed(2)}%) —{" "}
          {margin >= targetMargin ? (
            <span className="text-green-600 font-bold">✅ Healthy</span>
          ) : (
            <span className="text-red-600 font-bold">❌ Below Target</span>
          )}
        </p>

        {flagged.length > 0 && (
          <div>
            <p className="font-semibold text-red-600">⚠️ Low Margin Items:</p>
            <ul className="list-disc list-inside">
              {flagged.map((item, i) => (
                <li key={i}>{item.name} — Margin: {(item.margin * 100).toFixed(2)}%</li>
              ))}
            </ul>
          </div>
        )}

        {aiSuggestions && (
          <div className="mt-4 p-4 bg-blue-50 border-l-4 border-blue-500">
            <h3 className="font-semibold text-blue-700 mb-2">AI Suggestions:</h3>
            <p>{aiSuggestions}</p>
          </div>
        )}

        <button
          onClick={exportPDF}
          className="mt-4 px-6 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition"
        >
          📄 Download PDF
        </button>
      </div>
    </div>
  );
}
