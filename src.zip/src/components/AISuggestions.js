import React from 'react';

export default function AISuggestions({ text }) {
  if (!text) {
    return (
      <div className="mt-4 p-4 text-gray-500 italic">
        No AI suggestions yet.
      </div>
    );
  }

  return (
    <div className="mt-4 p-6 bg-green-50 border border-green-200 rounded shadow">
      <h3 className="text-lg font-semibold text-green-700 mb-2">
        AI Suggestions
      </h3>
      <p className="whitespace-pre-line text-green-800">
        {text}
      </p>
    </div>
  );
}
