import React from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from "react-router-dom";

export default function Menu() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <>
      <nav className="flex space-x-4 p-4 bg-gray-100 border-b mb-6">
        <Link to="/indexpage" className="text-blue-600 hover:underline">
          Home
        </Link>
        <Link to="/inputform" className="text-blue-600 hover:underline">
          Profit optimiser
        </Link>
        {/* <Link to="/inputform2" className="text-blue-600 hover:underline">Profitability</Link> */}

        <Link to="/healthindicator" className="text-blue-600 hover:underline">
          Health Indicator
        </Link>

        
        <Link to="/profitchecker" className="text-blue-600 hover:underline">Profit Checker</Link>
        <Link to="/dashboard" className="text-blue-600 hover:underline">Dashboard</Link>
      </nav>

      <nav className="p-4 bg-indigo-600 text-white flex justify-between">
        <span className="font-bold">Specifi Profit Optimiser</span>
        <button
          onClick={handleLogout}
          className="bg-white text-indigo-700 px-4 py-2 rounded"
        >
          Logout
        </button>
      </nav>
    </>
  );
}