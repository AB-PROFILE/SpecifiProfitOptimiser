import React, { useState } from 'react';
import Input from './Input';
import Button from './Button';


export default function ProfitChecker() {
  const [revenue, setRevenue] = useState('');
  const [costs, setCosts] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setResult(null);

    try {
      const response = await fetch('http://localhost:5000/api/check_profitability', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          revenue: Number(revenue),
          costs: Number(costs)
        })
      });

      const data = await response.json();
      if (response.ok) {
        setResult(data);
      } else {
        setError(data.error || 'Something went wrong.');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
  
    <div className="max-w-md mx-auto p-4 border rounded">
      <h2 className="text-xl font-bold mb-4">Check Profitability</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block font-medium">Revenue (£)</label>
          <input
            type="number"
            value={revenue}
            onChange={(e) => setRevenue(e.target.value)}
            className="border p-2 w-full rounded"
            required
          />
        </div>
        <div>
          <label className="block font-medium">Costs (£)</label>
          <input
            type="number"
            value={costs}
            onChange={(e) => setCosts(e.target.value)}
            className="border p-2 w-full rounded"
            required
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          {loading ? 'Checking...' : 'Check Profitability'}
        </button>
      </form>

      {error && <p className="text-red-600 mt-4">{error}</p>}

      {result && (
        <div className="mt-6 p-4 border rounded bg-gray-50">
          <h3 className="font-semibold">Result:</h3>
          <p>Profit: £{result.profit}</p>
          <p>Profit Margin: {result.profit_margin.toFixed(2)}%</p>
          <p>Is Profitable: {result.is_profitable ? 'Yes' : 'No'}</p>
          <h4 className="mt-4 font-semibold">AI Suggestion:</h4>
          <p>{result.suggestion}</p>
        </div>
      )}
    </div>
  );
}
