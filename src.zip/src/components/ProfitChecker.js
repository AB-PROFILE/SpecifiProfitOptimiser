import React, { useState } from "react";
// import InputForm from "./InputForm";
import ResultsDisplay from "./ResultsDisplay";
// import { calculateTotals } from "../utils/calculations";
// import bomData from "../data/bom.json";
import AISuggestions from './AISuggestions';
import HealthIndicator from './HealthIndicator';

export default function ProfitChecker() {
  const [rowIndex, setRowIndex] = useState(0);
  const [profitResult, setProfitResult] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch("http://127.0.0.1:5000/api/check_profitability", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ row_index: Number(rowIndex) }),
    });
    const data = await res.json();
    setProfitResult(data);
  };

  return (
    <div className="p-6">
      <form onSubmit={handleSubmit} className="mb-4">
        <input
          type="number"
          value={rowIndex}
          onChange={(e) => setRowIndex(e.target.value)}
          className="border p-2 mr-2"
        />
        <button
          type="submit"
          className="bg-indigo-600 text-white px-4 py-2 rounded"
        >
          Check Profitability
        </button>
      </form>

      {profitResult && (
        <>
          <ResultsDisplay result={profitResult} />
          <HealthIndicator 
            margin={profitResult.margin || 0} 
            targetMargin={profitResult.targetMargin || 0} 
          />
        </>
      )}
    </div>
  );
}
