import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import Menu from './components/Menu';
import InputForm from './components/InputForm';
// import ResultsDisplay from "./ResultsDisplay";
import ProfitChecker from './components/ProfitChecker';
import HealthIndicator from './components/HealthIndicator';
import LoginPage from './components/LoginPage';
import SignUp from './components/SignUp';
import IndexPage from './components/IndexPage';
import Dashboard from './components/Dashboard';
import './index.css';
import ProtectedRoute from './components/ProtectedRoute';
import Profile from './components/Profile';


const isAuth = true; // <-- in real app, this comes from your auth state!
const API_BASE = process.env.REACT_APP_API_URL || "http://127.0.0.1:5000";


function Home() {
  return (
    <>
      <main className="min-h-screen bg-gray-100 flex items-center justify-center p-8">
        <ProfitChecker />
      </main>
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
        <h1 className="text-4xl font-bold mb-4">Welcome to Specifi Profit Optimiser</h1>
        <div className="space-x-4">
          <Link
            to="/login"
            className="bg-white text-indigo-700 px-6 py-3 rounded font-semibold hover:bg-indigo-100 transition"
          >
            Login
          </Link>
          <Link
            to="/signup"
            className="bg-white text-indigo-700 px-6 py-3 rounded font-semibold hover:bg-indigo-100 transition"
          >
            Sign Up
          </Link>
        </div>
      </div>
    </>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<IndexPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignUp />} />
        
        {/* Protect the Dashboard */}
        <Route
  path="/dashboard/*"
  element={
    <ProtectedRoute>
      <Dashboard />
    </ProtectedRoute>
  }
/>

        {/* Other routes */}
        <Route path="/inputform" element={<InputForm />} />
        {/* <Route path="/inputform2" element={<InputForm2 />} /> */}
        <Route path="/profitchecker" element={<ProfitChecker />} />
        <Route path="/healthindicator" element={<HealthIndicator />} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}
