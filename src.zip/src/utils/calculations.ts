export function calculateTotals(products: any[], laborHours: number, laborCost: number, overheads: number) {
  let totalCost = 0;
  let totalRevenue = 0;
  let flagged: any[] = [];

  products.forEach(item => {
    const cost = item.cost * item.quantity;
    const revenue = item.sell * item.quantity;
    const margin = (revenue - cost) / revenue;

    if (margin < 0.1) {
      flagged.push({ ...item, margin });
    }

    totalCost += cost;
    totalRevenue += revenue;
  });

  const totalLabor = laborHours * laborCost;
  const totalCosts = totalCost + totalLabor + overheads;
  const profit = totalRevenue - totalCosts;
  const margin = totalRevenue ? profit / totalRevenue : 0;

  return {
    totalRevenue,
    totalCosts,
    profit,
    margin,
    flagged,
  };
}
