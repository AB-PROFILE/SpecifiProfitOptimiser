import React, { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(localStorage.getItem("token") || null);
  const [expiry, setExpiry] = useState(localStorage.getItem("token_expiry") || null);

  useEffect(() => {
    if (token && expiry) {
      localStorage.setItem("token", token);
      localStorage.setItem("token_expiry", expiry);
    } else {
      localStorage.removeItem("token");
      localStorage.removeItem("token_expiry");
    }
  }, [token, expiry]);

  useEffect(() => {
    if (token && expiry) {
      const remaining = new Date(expiry).getTime() - Date.now();
      const timer = setTimeout(() => {
        logout();
      }, remaining);
      return () => clearTimeout(timer);
    }
  }, [token, expiry]);

  const login = (newToken, expiresInSeconds = 3600) => {
    setToken(newToken);
    const expiryTime = new Date(Date.now() + expiresInSeconds * 1000);
    setExpiry(expiryTime.toISOString());
  };

  const logout = () => {
    setToken(null);
    setExpiry(null);
  };

  const isAuthenticated = !!token && (!expiry || new Date(expiry) > new Date());

  return (
    <AuthContext.Provider value={{ token, login, logout, isAuthenticated }}>
      {children}
    </AuthContext.Provider>
  );
};

// ✅ THIS IS MISSING — ADD IT!
export const useAuth = () => useContext(AuthContext);
